from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import traceback
from typing import Any

import signal
from contextlib import contextmanager
import sys, os
import time
from enum import Enum
import multiprocessing as mp
from io import StringIO # Python3 use: from io import StringIO


class Status(str,Enum):
    TLE = "TLE"
    RE = "RE"
    AC = "AC"
    WA = "WA"
    # PASS_TEST = 5
    # RE_TEST = 6
    INVALID_INPUT = "INVALID_INPUT"
    VALID_INPUT = "VALID_INPUT"

@dataclass
class Result():
    status:Status
    test_desc: str|None = None
    msg: str|None = None
    msg_output: str|None = None
    msg_expected: str|None = None
    result: Any = None
    stdout: str|None = None
    def to_response(self, config):
        # config "test" and "submit" are negation of each other
        status = "Accepted"
        returned_msg = []

        if config["test"] and self.stdout is not None:
            returned_msg.append("Standard Out:")
            returned_msg.append(self.stdout)
        
        match self.status:
            case Status.AC:
                status = "Accepted" 
                returned_msg.append("Accepted" if config["submit"] else f"Correct on {self.test_desc}")
            case Status.WA:
                status = "Wrong Answer"
                returned_msg.append(f"Wrong Answer on {self.test_desc}")
            case Status.TLE:
                status = "Time Limit Exceeded"
                returned_msg.append(f"Time Limit Exceeded on {self.test_desc}")
            case Status.RE:
                status = "Runtime Error"
                returned_msg.append(f"Runtime Error on {self.test_desc}")
            case Status.INVALID_INPUT:
                status = "Invalid Input"
                returned_msg.append(f"Invalid Input for {self.test_desc}")

        if config["test"] and self.msg is not None:
            returned_msg.append(self.msg)
        if config["test"] and self.msg_output is not None:
            returned_msg.append("Your output:")
            returned_msg.append(self.msg_output)
        if config["test"] and self.msg_expected is not None:
            returned_msg.append("Expected output:")
            returned_msg.append(self.msg_expected)

        return {"status": status, "msg": "\n".join(returned_msg)}


# Timeout: https://stackoverflow.com/a/63546765
@contextmanager
def time_limit(seconds):
    def signal_handler(signum, frame):
        raise TimeoutError("Timed out!")
    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0)


# hide stdout and stderr: https://stackoverflow.com/questions/8391411/how-to-block-calls-to-print
class HiddenPrints:
    def __init__(self, mp_queue):
        self.mp_queue = mp_queue


    def __enter__(self):
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        self._capturing_io = StringIO()
        sys.stdout = self._capturing_io
        # sys.stderr = StringIO()

        # sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.mp_queue.put(self._capturing_io.getvalue())
        self._capturing_io.close()
        sys.stdout.close()
        sys.stdout = self._original_stdout
        sys.stderr.close()
        sys.stderr = self._original_stderr
        
    


class BaseSolution:
    def solve(self, *input):
        raise NotImplementedError()
    def ret2str(self, ans):
        raise NotImplementedError()

class BaseProblem:
    solution:BaseSolution = BaseSolution()
    golden_solution:BaseSolution = BaseSolution()
    custom_in_path:Path = Path()
    solution_path:Path = Path()

    def get_hidden_tests(self,):
        raise NotImplementedError()
    def read_custom_input(self,):
        raise NotImplementedError()

    @classmethod
    def upload_custom_test(self,file):
        raise NotImplementedError()
    @classmethod
    def upload_solution(self,file):
        raise NotImplementedError()
    
    def check(self, ans, expected) -> bool:
        raise NotImplementedError()
    
    def run_test(self, testcase, test_desc):
        q = mp.Queue()
        p = mp.Process(target=BaseProblem.run_test_process, args=(self, testcase, test_desc,q))
        # print("parent: process prepared")
        p.start()
        # print("parent: process started")
        stdout = q.get()
        res:Result = q.get()
        # print("parent: result get")
        p.join()
        # print("parent: joined")
        res.stdout = stdout
        return res

    def run_test_process(self, testcase, test_desc, mp_queue):
        # print("child: started running")
        input, expected = testcase
        try:
            with time_limit(5), HiddenPrints(mp_queue):
                start_time = time.process_time()
                ans = self.solution.solve(*input)
                end_time = time.process_time()
        except TimeoutError:
            mp_queue.put(Result(Status.TLE, test_desc=test_desc, msg="Used >5 seconds"))
            return 
        except Exception:
            mp_queue.put(Result(Status.RE, test_desc=test_desc, msg=traceback.format_exc()))
            return 
        if end_time - start_time > 2:
            mp_queue.put(Result(Status.TLE, test_desc=test_desc, msg="Used " + str(end_time - start_time) + " seconds"))
            return
        ac = self.check(ans, expected)
        if ac:
            mp_queue.put(Result(Status.AC, test_desc=test_desc, msg_output=self.solution.ret2str(ans)))
            return 
        else:
            mp_queue.put(Result(Status.WA, test_desc=test_desc, msg_output=self.solution.ret2str(ans), msg_expected=self.solution.ret2str(expected)))
            return 

    def test(self) -> Result:
        input_status = self.read_custom_input()
        if input_status.status == Status.INVALID_INPUT:
            result = Result(Status.INVALID_INPUT, test_desc="custom test", msg=input_status.msg)
        else:
            input = input_status.result
            expected = self.golden_solution.solve(*input)
            result = self.run_test((input, expected), "custom test")
        return result

    def submit(self) -> Result:
        for input_gen, ans_gen, description in self.get_hidden_tests():
            input = input_gen()
            expected = ans_gen()
            if expected is None:
                expected = self.golden_solution.solve(*input)
            result = self.run_test((input, expected), description)
            if result.status != Status.AC:
                return result
        return Result(Status.AC)
    
    def test_all_hidden(self, config) -> list[Result]:
        results = []
        for input_gen, ans_gen, description in self.get_hidden_tests():
            input = input_gen()
            expected = ans_gen()
            if expected is None:
                expected = self.golden_solution.solve(*input)
            result = self.run_test((input, expected), description)
            results.append(result)
        return results

if __name__ == '__main__':
    ctx = mp.get_context('spawn')