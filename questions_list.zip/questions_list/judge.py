# Judge server that does the following:
# Test on custom input
# Judge on entire dataset
from collections import defaultdict
import json
from typing import Any
from fastapi import FastAPI, HTTPException
from enum import Enum
from questions_list.problems import problem_dict
from fastapi.responses import JSONResponse
import datetime
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
from shutil import copyfile


import os
data_path = (Path(os.path.abspath(__file__)) / "../../../pilot_analyze/data").resolve()

judge_app = FastAPI()
TEST_LENGTH_IN_MINUTES = 16

origins = ["*"]

judge_app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


INIT_SESSION_LOOKUP_KEY = "0"
class Session:
    def __init__(self) -> None:
        self.session_start_time = datetime.datetime.now()
        self.session_id = str(abs(hash(datetime.datetime.now())))
        self.data_folder = data_path / f"{self.session_id}"
        self.data_folder.mkdir(parents=True, exist_ok=True)
        self.log_path = self.data_folder / "session.log"
        self.log_path.touch(exist_ok=True)
        self.logs:list[str] = []
        json_log = {
            "problem_id": "X",
            "action": "start_session",
            "request_time": 0,
            "wall_time": str(self.session_start_time),
        }
        self.log(json_log)

    def save_file(self, orig_path: Path, elapsed_seconds: int, problem_id: "Problem", test=True, input_file=False):
        new_filename = f"{problem_id.value}_{elapsed_seconds}_{'test' if test else 'submit'}.{'in' if input_file else 'py'}"
        new_path = self.data_folder / new_filename
        # print(f"copying {orig_path} to {new_path}")
        copyfile(orig_path, new_path)


    def log(self, x:dict):
        x["timestamp"] = self.get_microseconds_elapsed()
        
        logged_msg = json.dumps(x)

        self.logs.append(logged_msg)
        print(logged_msg)
        if sum(map(len, self.logs)) >= 2048:
            self.save_log_buffer()

    def get_microseconds_elapsed(self):
        return int((datetime.datetime.now() - self.session_start_time).total_seconds()*1000)

    def save_log_buffer(self):
        with open(self.log_path, "a") as f:
                f.write("\n".join(self.logs))
                f.write("\n")
                self.logs = []

    def close(self):
        self.save_log_buffer()
                
sessions:defaultdict[str, "Session"] = defaultdict(Session)
class Problem(str, Enum):
    A = "A"
    B = "B"
    E = "E"
    F = "F"
    G = "G"



def wrap_response_header(json_content):
    if "msg" in json_content:
        json_content["msg"] = "\n" + json_content["msg"] + "\n--------------"
    return json_content

def check_timeout(microseconds_elapsed):
    if microseconds_elapsed > TEST_LENGTH_IN_MINUTES * 60 * 1000:
        raise HTTPException(status_code=400, detail="Time Up. Judge Closed.")

# test 
@judge_app.get("/api/test")
def direct_test(problem_id: Problem):
    global sessions
    session = sessions[INIT_SESSION_LOOKUP_KEY]
    microseconds_elapsed = session.get_microseconds_elapsed()
    check_timeout(microseconds_elapsed)
    
    json_log = {
        "problem_id": problem_id.value,
        "action": "test_start",
        "request_time": microseconds_elapsed
    }
    session.log(json_log)

    config: dict[str, Any] = defaultdict(lambda:None)
    config["test"] = True
    config["submit"] = False

    problem_class = problem_dict[problem_id]
    problem = problem_class()
    result = problem.test()

    response_dict = result.to_response(config)
    response_dict["time_elapsed"] = str(microseconds_elapsed)
    response_dict["problem_id"] = problem_id.value
    response_dict["session_id"] = session.session_id

    json_log = {
        "problem_id": problem_id.value,
        "action": "test_response",
        "status": result.status.value,
        "response_dict": response_dict,
        "request_time": microseconds_elapsed
    }
    session.log(json_log)

    try:
        session.save_file(problem.custom_in_path, microseconds_elapsed, problem_id, test=True, input_file=True)
        session.save_file(problem.solution_path, microseconds_elapsed, problem_id, test=True, input_file=False)
    except FileNotFoundError:
        response_dict["save_file"] = "Failed"
    return wrap_response_header(response_dict)


@judge_app.get("/api/submit")
def direct_submit(problem_id: Problem):
    global sessions
    session = sessions[INIT_SESSION_LOOKUP_KEY]
    microseconds_elapsed = session.get_microseconds_elapsed()
    check_timeout(microseconds_elapsed)

    json_log = {
        "problem_id": problem_id.value,
        "action": "submit_start",
        "request_time": microseconds_elapsed
    }
    session.log(json_log)

    config: dict[str, Any] = defaultdict(lambda:None)
    config["test"] = False
    config["submit"] = True

    problem_class = problem_dict[problem_id]
    problem = problem_class()
    result = problem.submit()

    response_dict = result.to_response(config)
    response_dict["time_elapsed"] = str(microseconds_elapsed)
    response_dict["problem_id"] = problem_id.value
    response_dict["session_id"] = session.session_id

    json_log = {
        "problem_id": problem_id.value,
        "action": "submit_response",
        "status": result.status.value,
        "response_dict": response_dict,
        "request_time": microseconds_elapsed
    }
    session.log(json_log)
    try:
        session.save_file(problem.solution_path, microseconds_elapsed, problem_id, test=False, input_file=False)
    except FileNotFoundError:
        response_dict["save_file"] = "Failed"

    
    return wrap_response_header(response_dict)


@judge_app.post("/api/test")
def upload_test(problem_id: Problem):
    return "Not Impelemented"

@judge_app.post("/api/submit")
def upload_submit(problem_id: Problem):
    return "Not Impelemented"


# start timer
@judge_app.get("/api/start")
def start():
    global sessions
    if INIT_SESSION_LOOKUP_KEY in sessions:
        raise HTTPException(status_code=400, detail="Already Started")
    else:
        time = sessions[INIT_SESSION_LOOKUP_KEY].session_start_time
        session_id = sessions[INIT_SESSION_LOOKUP_KEY].session_id
        return wrap_response_header({"status": "OK", "start_time":time.strftime('%s'), "session_id": session_id})

@judge_app.get("/api/restart")
def restart():
    global sessions
    sessions[INIT_SESSION_LOOKUP_KEY].close()
    sessions[INIT_SESSION_LOOKUP_KEY] = Session()
    time = sessions[INIT_SESSION_LOOKUP_KEY].session_start_time
    session_id = sessions[INIT_SESSION_LOOKUP_KEY].session_id
    return wrap_response_header({"status": "OK", "start_time":time.strftime('%s'), "session_id": session_id})

@judge_app.get("/api/close")
def close():
    global sessions
    session_id = sessions[INIT_SESSION_LOOKUP_KEY].session_id
    sessions[INIT_SESSION_LOOKUP_KEY].close()
    del sessions[INIT_SESSION_LOOKUP_KEY]
    return wrap_response_header({"status": "Session closed", "session_id": session_id})

@judge_app.get("/test/{test}")
def ping(test:str):
    return wrap_response_header({"echoing": test})


@judge_app.get("/")
async def root():
    return wrap_response_header({"message": "Hello World"})

@judge_app.on_event("shutdown")
def shutdown_event():
    for session in sessions.values():
        session.close()