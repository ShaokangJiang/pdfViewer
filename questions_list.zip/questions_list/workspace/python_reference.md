# General
```python
# len() can be used on any container
a = [1,2,3,4]
print(len(a)) # prints 4

# tuple
a = (1, 2)
print(a[0]) # prints 1
x, y = a # unpacking
print(x, y) # prints 1 2

# min max sort
a = [1,3,2]
a.sort() # sort in place
b = sorted(a) # sort out of place

max(a) # get max
min(a) # get min
max(a,default=0) # get max, return 0 if empty
bb = [("a", 1), ("b", 2), ("c", 3)]
max(bb, key=lambda x: x[0]) # get the tuple with the maximum second entry
```

# list
```python
a = [0] * 1000 # a list of 1000 zeros

a.append(b) # append element to the end of the 

aa = [-1,2,3,-2,4]
bb = [a * 2 for x in aa if x > 0] # list comprehension: filter and map
print(bb) # prints [4, 6, 8]
```

# enumerate
```python
aa = ["a","b", "c", "d"]
for idx, a in enumerate(aa):
    print(idx, a)
# prints:
# 0 a
# 1 b
# 2 c
# 3 d
```

# Dictionary
```python
# initialize
a = {}
a = {"a":1, "b":2}

# access/change element
a["c"] = 3
a["a"] = 0
print(a["a"] + a["b"]) # prints 3

# enumeration
for key, value in a.items():
    print(key, value)
# prints the following:
# a 0
# b 2
# c 3

a = defaultdict(lambda: 0) # dict with default value 0
a = defaultdict(lambda: []) # dict with default value []
```

# Set
```python
# initialize
a = set()
a = {1,2,3}

# add/remove element
a.add(4)
a.remove(3)

# enumeration
for element in a:
    print(element)
# prints the following in an arbitrary order
# 1
# 2
# 4
```