# Type Hint Tutorial
Python 3.5 added type hint which can give Python type checkers hints for type inference. This document serves as a tutorial for using type hints in competitive programming in Python3.10. 

## Warm-up exercise
You can use Question F as a warm-up question to get familiar with type hints.

### Quick Reference:
```python
# primitives
count: int = 0 
pi: float = 3.141593 
nada: None = None 

# function
def area(radius: int) -> float: 
    return pi * radius ** 2

# containers
side_lenghts : tuple[int, bool] = (1,False) 
arr: list[float] = [0.0, 1.2, 3.5, pi] 
ages: dict[str, int] = {"Alice":28, "Bob":73} 
counter: defaultdict[str, int] = defaultdict(int) 

```


### Variables
To hint that variable `a` will have type `T`, we write `a: T`
For example:
```python
# count is an integer initialized to 0
count: int = 0 
# pi is a float initialized to 3.141593
pi: float = 3.141593 
# nada is None, this will be useful later when we have Union types.
nada: None = None 
```

### Functions
To hint that a function `func` take parameters `param1, param2` of type `T1, T2` and returns type `R`, we write
```python
def func(param1: T1, param2: T2) -> R:
    <function body>
```
For example:
```python
# computes area of circle with integer radius, returns float
def area(radius: int) -> float: 
    return pi * radius ** 2

# no return is equivalent to returning None, and returning None can be omitted
def send(message: str): 
    send_queue.append(message)
```

### Collections
In Python 3.10, collection item types can be added to brackets, preceeded by the collection name. For example:
```python
# tuple of (integer, boolean)
side_lenghts : tuple[int, bool] = (1,False) 
# list of floats
arr: list[float] = [0.0, 1.2, 3.5, pi] 
# dictionary of string keys and int values
ages: dict[str, int] = {"Alice":28, "Bob":73} 
# dictionary of string keys, int values, and default value 0
counter: defaultdict[str, int] = defaultdict(int) 
``` 


### Union Types
We can hint for multiple possible types using the `|` operator. To hint a type might be `T1` or `T2`, use `T1|T2`. Unioning `T1` with `None` type is the same as an optional type `Optional[T1]`.

For example:
```python
# Returns an integer or None type. int|None is the same as Optional[int]
def get(key:str) -> int|None:          
    if key not in private_dictionary:
        return None
    return private_dictionary[key]
```

### Classes
Name of classes can be use directly as the type of its objects.
For example:
```python
class A:
    pass
a: A = A() # a is an object of class A
```

Instance variables types are declared in the class body
For example:
```python
class A:
    # instance variable integer x with default value 100
    x: int = 100 

print(A().x) # prints 100
```

### Generics
You probably won't need this, but in case you want a generic type variable, use `TypeVar` to declare one.
For example:
```python
T = TypeVar('T')
# The identity function, the returned type is the same as input type.
def identity(x: T) -> T: 
    return x
```

