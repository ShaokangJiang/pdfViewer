
# Condition 2: strict type hint
from collections import defaultdict # type: ignore


class Solution:
    def arrayMedium(self, arr: list[int]) -> float:
        # Write your solution here)
        arr.sort()
        arr_len = len(arr)
        if arr_len == 0: 
            return arr[0]
        half = arr_len // 2
        if arr_len % 2 == 0: 
            return (arr[half - 1] + arr[half]) / 2
        else: 
            return arr[half]
        return 0
    def ret2str(self, ret:float):
        # This controls how your result is printed when testing
        return str(ret)