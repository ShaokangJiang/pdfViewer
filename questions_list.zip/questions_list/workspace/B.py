# LeetCode 990
# Condition 2: strict type hint
from collections import defaultdict # type: ignore
from typing import Literal 

class DisjointSet():
    # Disjoint Set data structure. Elements are integers from 0 to n.
    def __init__(self, n: int) -> None:
        # n is the amount of item needed. Elements are integers from 0 to n
        self.data = [x for x in range(n+1)]
        self.size = [1 for _ in range(n+1)]

    def find(self, x: int):
        # find the root for item x
        root = x
        while self.data[root] != root:
            root = self.data[root]
        while self.data[x] != root:
            p = self.data[x]
            self.data[x] = root
            x = p
        return root

    def union(self, x: int, y: int):
        # union sets that x and y are in
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        if self.size[px] < self.size[py]:
            px, py = py, px
        self.data[py] = px
        self.size[px] += self.size[py]

    def connected(self, x: int, y: int):
        # check if x and y are in the same set
        return self.find(x) == self.find(y)

    def set_size(self, x: int):
        # return the size of the set that x is in
        return self.size[self.find(x)]

class Solution:
    def equalitySatisfiability(self, equations: list[tuple[str, Literal["==","!="], str]]) -> bool:
        # Write your solution here
        ds = DisjointSet(len(equations) * 2)
        symbols = set()
        

        return True
    
    def ret2str(self, ret:bool):
        # This controls how your result is printed when testing
        return str(ret)