from .A_most_popular_creator.tester import Problem_A
from .B_equality_satisfiability.tester import Problem_B
from .E_array_medium.tester import Problem_E
from .F_second_largest_in_array.tester import Problem_F
from .G_coin_change.tester import Problem_G
from .tester import BaseProblem
problem_dict: dict[str, type[BaseProblem]] = {
    "A": Problem_A,
    "B": Problem_B,
    "E": Problem_E,
    "F": Problem_F,
    "G": Problem_G,
}