
# Condition 2: strict type hint
from collections import defaultdict # type: ignore


class Solution:
    def arrayMedium(self, arr: list[int]) -> float:
        # Write your solution here
        return 0
    def ret2str(self, ret:float):
        # This controls how your result is printed when testing
        return str(ret)