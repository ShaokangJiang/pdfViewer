from math import sqrt
from typing import Any, Iterable, Literal, TypeVar, Callable
import numpy as np
import time
N = 3 * 10 ** 5
MAX_INT = 10 ** 9
def print_iter(l: Iterable[Any]):
    print(" ".join(map(str, l)))


def radnom_odd() -> tuple[tuple[list[int]], float]:
    arr = np.random.randint(-MAX_INT, MAX_INT, N // 2 * 2 - 1)
    ans = np.median(arr)
    return (list(arr),), ans

def radnom_even() -> tuple[tuple[list[int]], float]:
    arr = np.random.randint(-MAX_INT, MAX_INT, N // 2 * 2 - 1)
    ans = np.median(arr)
    return (list(arr),), ans

lto = radnom_odd()
lte = radnom_even()

ans_True = lambda: True
ans_False = lambda: False
def ans_float(x:float):
    return lambda:x
T = TypeVar("T")
def reflect(x:T) -> Callable[[], T]:
    return lambda: x
    
tests = [
    (reflect(([1],)), ans_float(1), "small test 1"),
    (reflect(([2],)), ans_float(2), "small test 2"),
    (reflect(([1, 2],)), ans_float(1.5), "small test 3"),
    (reflect(([2, 1, 3],)), ans_float(2), "small test 4"),
    (reflect(([1, 2, 2],)), ans_float(2), "small test 5"),
    (reflect(([2,2,3,1],)), ans_float(2), "small test 6"),
    (reflect(([1,3,4,2],)), ans_float(2.5), "small test 7"),
    (reflect(([1,3,1,4],)), ans_float(2), "small test 8"),
    (reflect(([3,1,3,4],)), ans_float(3), "small test 9"),
    (reflect(([1,MAX_INT, MAX_INT],)), ans_float(MAX_INT), "small test 10"),
    (reflect(([-2, -1, -3],)), ans_float(-2), "small test 11"),
    (reflect(([-1,3,-4,2],)), ans_float(0.5), "small test 12"),
    (reflect(lto[0]), reflect(lto[1]), "large random test odd"),
    (reflect(lte[0]), reflect(lte[1]), "large random test even")
]

if __name__ == "__main__":
    
    for test_gen, answer_gen, _ in tests:
        start_time = time.process_time()
        test_gen()
        answer_gen()
        end_time = time.process_time()
        print(end_time - start_time)