
# Condition 2: strict type hint
from collections import defaultdict # type: ignore


class Solution:
    def arrayMedium(self, arr: list[int]) -> float:
        # Write your solution here)
        arr.sort()
        if len(arr) % 2 == 0:
            return (arr[len(arr) // 2 - 1] + arr[len(arr) // 2]) / 2
        else:
            return arr[len(arr) // 2]
    def ret2str(self, ret:float):
        # This controls how your result is printed when testing
        return str(ret)