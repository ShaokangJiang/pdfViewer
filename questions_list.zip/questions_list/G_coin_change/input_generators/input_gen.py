from typing import Any, Iterable, TypeVar, Callable
import numpy as np
import time
N = 1 * 10 ** 5
MAX_INT = 10 ** 9
M = 500
def print_iter(l: Iterable[Any]):
    print(" ".join(map(str, l)))


def radnom_test() -> tuple[list[int], int]:
    np.random.seed(42)
    target = np.random.randint(1000, N // 2)
    coins1 = np.random.randint(3, target-1, 400)
    coins2 = np.random.randint(target+1, MAX_INT, 100)
    return list(coins1) + list(coins2),target


lt = radnom_test()

ans_True = lambda: True
ans_False = lambda: False
def ans_float(x:float):
    return lambda:x
T = TypeVar("T")
def reflect(x:T) -> Callable[[], T]:
    return lambda: x
    
tests = [
    (reflect(([2,3,5],11)), reflect(3), "given test 1"),
    (reflect(([3],5)), reflect(-1), "given test 2"),
    (reflect(([5],3)), reflect(-1), "given test 3"),
    (reflect(([6, 9, 20],43)), reflect(-1), "small test 1"),
    (reflect(([6, 9, 20],44)), reflect(4), "small test 2"),
    (reflect(([2],2)), reflect(1), "small test 3"),
    (reflect(([MAX_INT, 1],23)), reflect(23), "small MAX_INT test 5"),
    (reflect(lt), reflect(None), "large random test"),
]

if __name__ == "__main__":
    
    for test_gen, answer_gen, _ in tests:
        start_time = time.process_time()
        test_gen()
        end_time = time.process_time()
        print(end_time - start_time)