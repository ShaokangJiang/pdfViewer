#! python


import traceback
from .input_generators.input_gen import tests as generated_tests
from questions_list.tester import BaseProblem, BaseSolution, Result, Status
from ..workspace.G import Solution as User_Solution
from .example_submissions.AC import Solution as Golden_Solution
from pathlib import Path
import os

ResType = int
InputType = tuple[list[int], int]

custom_in_path = (Path(os.path.abspath(__file__)) / "../../workspace/G.in").resolve()
solution_path = (Path(os.path.abspath(__file__)) / "../../workspace/G.py").resolve()

class Solution_G(BaseSolution):
    def __init__(self, solution) -> None:
        self.solution = solution
    def solve(self, *input):
        return self.solution.coinChange(*input)
    def ret2str(self, ans):
        return self.solution.ret2str(ans)
    
class Problem_G(BaseProblem):
    solution = Solution_G(User_Solution())
    golden_solution = Solution_G(Golden_Solution())
    custom_in_path = custom_in_path
    solution_path = solution_path

    def check(self, ans: ResType, expected: ResType):
        return ans == expected

    def get_hidden_tests(self,):
        return generated_tests

    def read_custom_input(self):
        try:
            arr:list[int] = []
            with open(self.custom_in_path) as f:
                arr = list(map(int, f.readline().split()))
                target = int(f.readline().strip())
                if len(arr) < 1:
                    return Result(Status.INVALID_INPUT, msg="Coins list must have at least one integer")
                if any(x <= 0 for x in arr) or target <= 0:
                    return Result(Status.INVALID_INPUT, msg="Input should all be positive integers")
        except ValueError:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        except Exception:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        return Result(Status.VALID_INPUT, result=(arr,target))

    @classmethod
    def upload_custom_test(self, file):
        raise NotImplementedError()

    @classmethod
    def upload_solution(self, file):
        raise NotImplementedError()

# if __name__ == "__main__":
#     if len(sys.argv) == 1:
#         print(""" tester.py usage: 
# - to test with "custom.in":    python tester.py test
# - to submit for evaluation:  python tester.py submit""")
#         exit(0)
#     if "--dev" in sys.argv:
#         dev = True
#     if "--run_all" in sys.argv:
#         run_all = True
#     if sys.argv[1] == "test":
#         res = run_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "submit":
#         res = judge_all_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "dev":
#         in_path = sys.argv[2]
#         res = run_test(Solution(), in_path)
#         exit(print_result(res))
    