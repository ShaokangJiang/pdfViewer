
# Condition 1: no type hint
from collections import defaultdict # type: ignore


class Solution:
    def coinChange(self, coins, target):
        # Write your solution here
        return 0

    def ret2str(self, ret):
        # This controls how your result is printed when testing
        return str(ret)