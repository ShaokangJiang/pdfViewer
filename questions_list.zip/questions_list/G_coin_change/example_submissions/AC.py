
# Condition 2: strict type hint
from collections import defaultdict # type: ignore
MAX_INT = 10 ** 9 + 3

class Solution:
    def coinChange(self, coins: list[int], target: int) -> int:
        # Write your solution here
        mem = [0]
        for i in range(1, target + 1):
            mem.append(1 + min((mem[-c] for c in coins if c <= i), default=MAX_INT)) 
        return -1 if mem[-1] >= MAX_INT else mem[-1]

    def ret2str(self, ret:int):
        # This controls how your result is printed when testing
        return str(ret)