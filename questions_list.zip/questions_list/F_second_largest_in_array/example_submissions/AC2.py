
# Condition 2: strict type hint
from collections import defaultdict # type: ignore


class Solution:
    def secondLargestInArray(self, arr: list[int]) -> int:
        # Write your solution here
        arr.sort()
        return arr[-2]

    def ret2str(self, ret:int):
        # This controls how your result is printed when testing
        return str(ret)