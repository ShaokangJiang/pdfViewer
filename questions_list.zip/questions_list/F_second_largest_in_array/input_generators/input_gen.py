from typing import Any, Iterable, TypeVar, Callable
import numpy as np
import time
N = 3 * 10 ** 5
MAX_INT = 10 ** 9
def print_iter(l: Iterable[Any]):
    print(" ".join(map(str, l)))


def radnom_test() -> tuple[tuple[list[int]], float]:
    arr = np.random.randint(0, MAX_INT, N // 2 * 2 - 1)
    ans = np.partition(arr, -2)[-2]
    return (list(arr),), ans


lt = radnom_test()

ans_True = lambda: True
ans_False = lambda: False
def ans_float(x:float):
    return lambda:x
T = TypeVar("T")
def reflect(x:T) -> Callable[[], T]:
    return lambda: x
    
tests = [
    (reflect(([0,0],)), reflect(0), "small test 1"),
    (reflect(([0,1],)), reflect(0), "small test 2"),
    (reflect(([1, 0],)), reflect(0), "small test 3"),
    (reflect(([3,2,1],)), reflect(2), "small test 4"),
    (reflect(([2,3,1],)), reflect(2), "small test 5"),
    (reflect(([1,1,3],)), reflect(1), "small test 6"),
    (reflect(([3,3,1],)), reflect(3), "small test 7"),
    (reflect(([1,6,45,4, MAX_INT],)), reflect(45), "small test 8"),
    (reflect(([1,MAX_INT, MAX_INT],)), reflect(MAX_INT), "small test 9"),
    (reflect(lt[0]), reflect(lt[1]), "large random test"),
]

if __name__ == "__main__":
    
    for test_gen, answer_gen, _ in tests:
        start_time = time.process_time()
        test_gen()
        answer_gen()
        end_time = time.process_time()
        print(end_time - start_time)