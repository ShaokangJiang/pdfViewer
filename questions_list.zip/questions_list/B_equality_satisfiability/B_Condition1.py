# LeetCode 990
# Condition 1: no type hint
from collections import defaultdict # type: ignore

class DisjointSet():
    # Disjoint Set data structure. Elements are integers from 0 to n.
    def __init__(self, n):
        # n is the amount of item needed. Elements are integers from 0 to n
        self.data = [x for x in range(n+1)]
        self.size = [1 for _ in range(n+1)]

    def find(self, x):
        # find the root for item x
        root = x
        while self.data[root] != root:
            root = self.data[root]
        while self.data[x] != root:
            p = self.data[x]
            self.data[x] = root
            x = p
        return root

    def union(self, x, y):
        # union sets that x and y are in
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        if self.size[px] < self.size[py]:
            px, py = py, px
        self.data[py] = px
        self.size[px] += self.size[py]

    def connected(self, x, y):
        # check if x and y are in the same set
        return self.find(x) == self.find(y)

    def set_size(self, x):
        # return the size of the set that x is in
        return self.size[self.find(x)]

class Solution:
    def equalitySatisfiability(self, equations):
        # Write your solution here
        return True
    
    def ret2str(self, ret):
        # This controls how your result is printed when testing
        return str(ret)