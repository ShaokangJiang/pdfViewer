import traceback
from typing import Literal
from questions_list.tester import BaseProblem, BaseSolution, Result, Status
from ..workspace.B import Solution as User_Solution
from .input_generators.input_gen import tests as generated_tests
from .example_submissions.AC import Solution as Golden_Solution
from pathlib import Path
import os

ResType = bool
InputType = tuple[list[tuple[str, Literal["==","!="], str]]]


custom_in_path = (Path(os.path.abspath(__file__)) / "../../workspace/B.in").resolve()
solution_path = (Path(os.path.abspath(__file__)) / "../../workspace/B.py").resolve()

class Solution_B(BaseSolution):
    def __init__(self, solution) -> None:
        self.solution = solution
    def solve(self, *input):
        return self.solution.equalitySatisfiability(*input)
    def ret2str(self, ans):
        return self.solution.ret2str(ans)
    
class Problem_B(BaseProblem):
    solution = Solution_B(User_Solution())
    golden_solution = Solution_B(Golden_Solution())
    custom_in_path = custom_in_path
    solution_path = solution_path

    def check(self, ans: ResType, expected: ResType):
        return ans == expected

    def get_hidden_tests(self,):
        return generated_tests

    def read_custom_input(self):
        try:
            equations:list[tuple[str, Literal["!=", "=="], str]] = []
            with open(self.custom_in_path) as f:
                for line in f:
                    equation = tuple(line.split())
                    if len(equation) != 3:
                        return Result(Status.INVALID_INPUT, msg="Input must have three space separated tokens")
                    if equation[1] != "==" and equation[1] != "!=":
                        return Result(Status.INVALID_INPUT, msg="second token on a line must be '==' or '!='")
                    equations.append(equation)      # type: ignore       
                if len(equations) == 0:
                    return Result(Status.INVALID_INPUT, msg="Must have at least one equation")
        except ValueError as e:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        except Exception as e:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        return Result(Status.VALID_INPUT, result=(equations,))
    
    @classmethod
    def upload_custom_test(self, file):
        raise NotImplementedError()

    @classmethod
    def upload_solution(self, file):
        raise NotImplementedError()

# if __name__ == "__main__":
#     if len(sys.argv) == 1:
#         print(""" tester.py usage: 
# - to test with "custom.in":    python tester.py test
# - to submit for evaluation:  python tester.py submit""")
#         exit(0)
#     if "--dev" in sys.argv:
#         dev = True
#     if "--run_all" in sys.argv:
#         run_all = True
#     if sys.argv[1] == "test":
#         res = run_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "submit":
#         res = judge_all_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "dev":
#         in_path = sys.argv[2]
#         res = run_test(Solution(), in_path)
#         exit(print_result(res))
    