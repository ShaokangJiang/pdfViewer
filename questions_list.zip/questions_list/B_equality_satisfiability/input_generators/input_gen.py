from math import sqrt
from typing import Any, Callable, Iterable, Literal, TypeVar
import numpy as np
import time
N = 3 * 10 ** 5
MAX_INT = 10 ** 9
def print_iter(l: Iterable[Any]):
    print(" ".join(map(str, l)))


def bipartite_True():
    L = int(sqrt(N))
    ra, rb = range(L//3), range(L // 3, L//3 * 2)
    first = [(str(a), "==", str(b)) for a in ra for b in ra]
    second = [(str(a), "==", str(b)) for a in rb for b in rb]
    uneq = [(str(a), "!=", str(b)) for a in ra for b in rb]
    return (first + second + uneq, )

def tripartite_True():
    L = int(sqrt(N))
    ra, rb, rc = range(L//4), range(L // 4, L//4 * 2), range(L // 4 * 2, L//4 * 3)
    first = [(str(a), "==", str(b)) for a in ra for b in ra]
    second = [(str(a), "==", str(b)) for a in rb for b in rb]
    third = [(str(a), "==", str(b)) for a in rc for b in rc]
    uneq1 = [(str(a), "!=", str(b)) for a in ra for b in rb]
    uneq2 = [(str(a), "!=", str(b)) for a in rb for b in rc]
    uneq3 = [(str(a), "!=", str(b)) for a in rc for b in ra]
    return (uneq1 + first + uneq3 + second + uneq2 + third, )

def all_reflex_True():
    ls = map(str, range(N))
    op = ["=="] * N
    rs = map(str, range(N))
    return (list(zip(ls, op, rs)),)

def long_link_True():
    ls = map(str, range(N))
    op = ["=="] * N
    rs = map(str, range(1,N+1))
    return (list(zip(ls, op, rs)), )

def large_cycle_True():
    ls = map(str, range(N))
    op = ["=="] * N
    rs = map(str, range(1,N+1))
    return (list(zip(ls, op, rs)) + [(str(0), "==", str(N))], )

def large_cycle_False():
    ls = map(str, range(N))
    op = ["=="] * N
    rs = map(str, range(1,N+1))
    return (list(zip(ls, op, rs)) + [(str(0), "!=", str(N))], )

def random_False() -> list[tuple[str, Literal["==", "!="], str]]:
    l = map(str,np.random.randint(0, N, N // 3))
    op = np.random.choice(["==", "!="], N // 3)
    r = map(str,np.random.randint(0, N, N // 3))
    return (list(zip(l, op, r)) + [("a", "!=", "b"), ("b", "==", "a")], )

ans_True = lambda: True
ans_False = lambda: False

T = TypeVar("T")
def reflect(x:T) -> Callable[[], T]:
    return lambda: x

tests = [
    (reflect(([
        ("a", "==", "b"), 
        ("b", "==", "c"), 
        ("c", "==", "a")
    ],)), ans_True, "given test 1"),
    (reflect(([
        ("a", "==", "b"), 
        ("b", "==", "c"),
        ("c", "!=", "a")
    ],)), ans_False, "given test 2"),
    (reflect(([
        ("a", "==", "b"), 
        ("a", "!=", "b")
    ],)), ans_False, "small test 1"),
    (reflect(([
        ("a", "==", "b"), 
        ("c", "==", "b"),
        ("a", "==", "c"),
    ],)), ans_True, "small test 2"),
    (reflect(([
        ("a", "!=", "a")
    ],)), ans_False, "small test 3"),
    (reflect(([
        ("alice", "==", "bob"), 
        ("fish", "!=", "alice"),
        ("this", "==", "that"),
        ("bob", "==", "chris"),
        ("bob", "!=", "eel"),
        ("chris", "==", "dig"),
        ("give", "==", "bob"),
        ("eel", "==", "fish"),
        ("nothing", "!=", "forever"),
        ("that", "==", "eel"),
        ("everything", "==", "here"),
        ("everything", "!=", "nothing"),
    ],)), ans_True, "small test 4"),
    
    (bipartite_True, ans_True, "large bipartite test"),
    (tripartite_True, ans_True, "large tripartite test"),
    (all_reflex_True, ans_True, "large reflexive test"),
    (large_cycle_True, ans_True, "large cycle test"),
    (large_cycle_False, ans_False, "large cycle test 2"),
    (random_False, ans_False, "large random test"),
]

if __name__ == "__main__":
    
    for test_gen, answer_gen, _ in tests:
        start_time = time.process_time()
        test_gen()
        answer_gen()
        end_time = time.process_time()
        print(end_time - start_time)