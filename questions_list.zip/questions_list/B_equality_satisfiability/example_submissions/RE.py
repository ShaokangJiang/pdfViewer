# LeetCode 990
# Condition 1: no type hint
from collections import defaultdict # type: ignore
from typing import Literal 

class DisjointSet():
    def __init__(self, n: int) -> None:
        self.data = [x for x in range(n+1)]
        self.size = [1 for _ in range(n+1)]

    def find(self, x: int):
        root = x
        while self.data[root] != root:
            root = self.data[root]
        while self.data[x] != root:
            p = self.data[x]
            self.data[x] = root
            x = p
        return root

    def union(self, x: int, y: int):
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        if self.size[px] < self.size[py]:
            px, py = py, px
        self.data[py] = px
        self.size[px] += self.size[py]

    def connected(self, x: int, y: int):
        return self.find(x) == self.find(y)

    def set_size(self, x: int):
        return self.size[self.find(x)]

class Solution:
    def equalitySatisfiability(self, equations: list[tuple[str, Literal["==","!="], str]]) -> bool:
        # Write your solution here
        raise IndexError()
    
    def ret2str(self, ret:bool):
        # This controls how your result is printed when testing
        return str(ret)