In `./material`, start server command:
```bash
uvicorn questions_list.judge:judge_app --port=8000 --log-level=debug --workers=1 --host=137.110.38.136 
```

Dependency:
`uvicorn`, `python3.10`, `numpy`, `fastapi`