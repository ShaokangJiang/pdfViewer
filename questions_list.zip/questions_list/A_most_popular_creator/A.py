# LeetCode 2456
from collections import defaultdict # type: ignore
from typing import Sequence # type: ignore
class Solution:
    def mostPopularCreator(self, creator_videos_dict: dict[str,list[tuple[int, str]]]) -> list[tuple[str, str]]:
        creator_popularity:list[tuple[int, str]] = []
        for creator, videos_views in creator_videos_dict.items():
            popularity = sum(v for v,_ in videos_views)
            creator_popularity.append((popularity, creator))
        creator_popularity.sort(reverse=True)
        
        highest = creator_popularity[0][0]
        ret: list[tuple[str, str]] = []

        for popularity, creator in creator_popularity:
            if popularity != highest:
                break
            creator_videos_dict[creator].sort(reverse=True)
            ret.append((creator, creator_videos_dict[creator][0][1]))

        return ret
        
    def ret2str(self, ret: list[tuple[str, str]]):
        # This controls how your result is printed when testing
        return "\n".join((" ".join(x for x in tup) for tup in ret))