from collections import defaultdict
import time
from typing import Callable, TypeVar
import numpy as np
N = 2 * 10 ** 5
MAX_INT = 10 ** 9

def large_test_1():
    return {str(x): [(x,str(x + N)), (N-x, str(x + 2*N))] for x in range(N//2)},
    

def random_test_1():
    creators = np.random.randint(low=0, high=N//4, size=(N,))
    ids = range(N)
    views = np.random.choice(N * 100, size=(N,), replace=False)
    ret = defaultdict(list)
    for c, i, v in zip(creators, ids, views):
        ret[str(c)].append((v, str(i)))
    return dict(ret),



T = TypeVar("T")
def reflect(x:T) -> Callable[[], T]:
    return lambda: x
    
tests = [
    (reflect(({
        "alice":[(6, "one"), (5, "three")],
        "bob": [(11, "two")],
        "chris": [(4, "four")],
    },)), reflect(None), "given test 1"),

    (reflect(({
        "alice":[(1, "a"), (2, "b"), (3, "c")],
        "bob": [(4, "d")],
    },)), reflect(None), "given test 2"),

    (reflect(({
        "alice":[(1, "a"), (2, "b"), (3, "c")],
    },)), reflect(None), "small test 1"),

    (reflect(({
        "alice":[(6, "a"), (5, "abc"), (10, "aab")],
        "bob": [(12, "two"), (9, "three")],
        "chris": [(21, "four")],
    },)), reflect(None), "small test 2"),

    (reflect(({
        "alice":[(1, "one")],
        "bob": [(2, "two")],
        "chris": [(3, "three")],
        "denis":[(4, "four"), (6, "six")],
        "eric": [(5, "five")],
        "fiona": [(8, "eight")],
    },)), reflect(None), "small test 3"),
    (large_test_1, reflect(None), "large test"),
    (random_test_1, reflect(None), "large random test"),
]



if __name__ == "__main__":
    for test_gen, answer_gen, _ in tests:
        start_time = time.process_time()
        test_gen()
        end_time = time.process_time()
        print(end_time - start_time)