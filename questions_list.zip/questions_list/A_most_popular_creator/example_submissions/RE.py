# LeetCode 2456
from collections import defaultdict # type: ignore
from typing import Sequence # type: ignore
import time
class Solution:
    def mostPopularCreator(self, creators: list[str], ids: list[str], views: list[int]) -> list[tuple[str, str]]:
        raise ValueError()
    
    def ret2str(self, ret: list[tuple[str, str]]):
        return "\n".join((" ".join(x for x in tup) for tup in ret))