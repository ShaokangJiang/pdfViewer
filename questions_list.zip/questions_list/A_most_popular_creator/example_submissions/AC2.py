# LeetCode 2456
from collections import defaultdict # type: ignore
from typing import Sequence # type: ignore
class Solution:
    def mostPopularCreator(self, creator_videos_dict: dict[str,list[tuple[int, str]]]) -> list[tuple[str, str]]:
        creator_popularity:list[tuple[int, str]] = []
        for creator, videos_views in creator_videos_dict.items():
            popularity = sum(v for v,_ in videos_views)
            creator_popularity.append((popularity, creator))
        max_popularity = max(creator_popularity)[0]
        max_pop_creators = [creator for pop, creator in creator_popularity if pop == max_popularity]
        
        ret: list[tuple[str, str]] = []

        for creator in max_pop_creators:
            best_video = max(creator_videos_dict[creator])[1]
            ret.append((creator, best_video))

        return ret
        
    def ret2str(self, ret: list[tuple[str, str]]):
        # This controls how your result is printed when testing
        return "\n".join((" ".join(x for x in tup) for tup in ret))