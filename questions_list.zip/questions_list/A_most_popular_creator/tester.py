from questions_list.tester import BaseProblem, BaseSolution, Result, Status
from collections import defaultdict
import traceback
from ..workspace.A import Solution as User_Solution
from .input_generators.input_gen import tests as generated_tests
from .example_submissions.AC import Solution as Golden_Solution
from pathlib import Path
import os

ResType = list[tuple[str, str]]
InputType = tuple[list[int], int]




custom_in_path = (Path(os.path.abspath(__file__)) / "../../workspace/A.in").resolve()
solution_path = (Path(os.path.abspath(__file__)) / "../../workspace/A.py").resolve()

class Solution_A(BaseSolution):
    def __init__(self, solution) -> None:
        self.solution = solution
    def solve(self, *input):
        return self.solution.mostPopularCreator(*input)
    def ret2str(self, ans):
        return self.solution.ret2str(ans)
    
class Problem_A(BaseProblem):
    solution = Solution_A(User_Solution())
    golden_solution = Solution_A(Golden_Solution())
    custom_in_path = custom_in_path
    solution_path = solution_path

    def check(self, ans: ResType, expected: ResType):
        ans_set = set(ans)
        exp_set = set(expected)
        return ans_set == exp_set

    def get_hidden_tests(self,):
        return generated_tests

    def read_custom_input(self):
        try:
            with open(self.custom_in_path) as f:
                input_: defaultdict[str, list[tuple[int, str]]] = defaultdict(list)
                count = 0
                for line in f:
                    count += 1
                    creator, idd, views = line.split()
                    input_[creator].append((int(views), idd))
        except ValueError as e:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        except Exception as e:
            return Result(Status.INVALID_INPUT, msg=traceback.format_exc())
        if len(input_) == 0:
            return Result(Status.INVALID_INPUT, msg="Input must have at least one record") 
        seti: set[int] = set()
        for lis in input_.values():
            seti |= {x for x,_ in lis}
        if len(seti) != count:
            return Result(Status.INVALID_INPUT, msg="Number of views must be unique") 
        return Result(Status.VALID_INPUT, result=(dict(input_),))
    
    @classmethod
    def upload_custom_test(self, file):
        raise NotImplementedError()

    @classmethod
    def upload_solution(self, file):
        raise NotImplementedError()

# if __name__ == "__main__":
#     if len(sys.argv) == 1:
#         print(""" tester.py usage: 
# - to test with "custom.in":    python tester.py test
# - to submit for evaluation:  python tester.py submit""")
#         exit(0)
#     if "--dev" in sys.argv:
#         dev = True
#     if "--run_all" in sys.argv:
#         run_all = True
#     if sys.argv[1] == "test":
#         res = run_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "submit":
#         res = judge_all_test(Solution())
#         exit(print_result(res))
#     elif sys.argv[1] == "dev":
#         in_path = sys.argv[2]
#         res = run_test(Solution(), in_path)
#         exit(print_result(res))
    